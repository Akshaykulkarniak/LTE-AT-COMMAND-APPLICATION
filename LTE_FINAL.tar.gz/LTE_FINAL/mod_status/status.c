/* FILE NAME : status.c 
 * APPLICATION : TO GET THE STATUS OF SIM
 * DATE : 25/01/2018
 * AKSHAY KULKARNI
 */ 



 #include <stdio.h>   /* Standard input/output definitions */
 #include <string.h>  /* String function definitions */
 #include <unistd.h>  /* UNIX standard function definitions */
 #include <fcntl.h>   /* File control definitions */
 #include <errno.h>   /* Error number definitions */
 #include <termios.h> /* POSIX terminal control definitions */
 #include<stdlib.h>   /* Standard Library  */

int open_port_1(void);
int open_port_2(void);
int open_port_3(void);
int open_port_4(void);

int GetSimStatus(int mod , char *stat) // function definition
{
  int fd;  // File descriptor
  int m,n,i;
  char buf[1000]={"\0"}; 
//  char com_0[30]={"AT\r"};  
  char com_1[30]={"AT+CPIN?\r"};  



switch (mod)
{
case 1:
  fd = open_port_1();
	break;
case 2:
  fd = open_port_2();
	break;
case 3:
  fd = open_port_3();
	break;
case 4:
  fd = open_port_4();
	break;
default :
 printf("No such Module \n");
	break;
}


 char stack[1000]={"\0"};
  // Read the configureation of the port

  struct termios options;
  tcgetattr( fd, &options );

  /* SEt Baud Rate */

  cfsetispeed( &options, B115200 );
  cfsetospeed( &options, B115200 );

  //I don't know what this is exactly

  options.c_cflag |= ( CLOCAL | CREAD );

  // Set the Charactor size

  options.c_cflag &= ~CSIZE; /* Mask the character size bits */
  options.c_cflag |= CS8;    /* Select 8 data bits */

  // Set parity - No Parity (8N1)

  options.c_cflag &= ~PARENB;
  options.c_cflag &= ~CSTOPB;
  options.c_cflag &= ~CSIZE;
  options.c_cflag |= CS8;

  options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);

  // Disable Software Flow control

  options.c_iflag &= ~(IXON | IXOFF | IXANY);

  // Chose raw (not processed) output

  options.c_oflag &= ~OPOST;

  if ( tcsetattr( fd, TCSANOW, &options ) == -1 )
    printf ("1Error with tcsetattr = %s\n", strerror ( errno ) );
  else
    //printf ( "%s\n", "tcsetattr succeed" );

  fcntl(fd, F_SETFL, FNDELAY);


  // Write some stuff !!!

 // m = write(fd, com_0, strlen(com_0));
  n = write(fd, com_1, strlen(com_1));
  if (n < 0)
    fputs("write() of 4 bytes failed!\n", stderr);
  else
    //printf ("Write succeed n  = %i\n", n );

  n=0;
  i=0;
  while (n<=1) 
  {
    n = read( fd, buf, sizeof(buf) );
    if(n>0)
    {
 char *token = strtok(buf, ":"); 
        printf("%s\n", token);
 //strcpy(stack,token); 
    // Keep printing tokens while one of the
    // delimiters present in str[].
//while (token != NULL)
    {

        token = strtok(NULL," \n");
        printf("%s\n", token);
	strcpy(stat,token);
 //break;   
}

//	printf("return %s",stat); 
      fflush(stdout);
    }
    //   i=i+1;
  }
close(fd);

}           



int open_port_1(void)
{
  int fd; /* File descriptor for the port */
  fd = open("/dev/ttyUSB2", O_RDWR | O_NOCTTY | O_NDELAY);
  if (fd == -1)
  {
    perror("MODULE 1 INACTIVE \n ");
    perror("open_port: Unable to open /dev/ttyUSB2- ");
 exit (0);
  }
  else
    fcntl(fd, F_SETFL, FNDELAY);
  return (fd);
}



int open_port_2(void)
{
  int fd; /* File descriptor for the port */
  fd = open("/dev/ttyUSB6", O_RDWR | O_NOCTTY | O_NDELAY);
  if (fd == -1)
  {
    perror("MODULE 2 INACTIVE \n ");
    perror("open_port: Unable to open /dev/ttyUSB6- ");
 exit (0);
  }
  else
    fcntl(fd, F_SETFL, FNDELAY);
  return (fd);
}


int open_port_3(void)
{
  int fd; /* File descriptor for the port */
  fd = open("/dev/ttyUSB10", O_RDWR | O_NOCTTY | O_NDELAY);
  if (fd == -1)
  {
    perror("MODULE 3 INACTIVE \n ");
    perror("open_port: Unable to open /dev/ttyUSB10- ");
 exit (0);
  }
  else
    fcntl(fd, F_SETFL, FNDELAY);
  return (fd);
}


int open_port_4(void)
{
  int fd; /* File descriptor for the port */
  fd = open("/dev/ttyUSB14", O_RDWR | O_NOCTTY | O_NDELAY);
  if (fd == -1)
  {
    perror("MODULE 4 INACTIVE \n ");
    perror("open_port: Unable to open /dev/ttyUSB14- ");
 exit (0);
  }
  else
    fcntl(fd, F_SETFL, FNDELAY);
  return (fd);
}





int main()
{
int modnum;
char stat[30];
printf("Enter Module Number : \n ");
scanf("%d",&modnum);
GetSimStatus(modnum,stat); // PARAMETERS : MODULE NUMBER (INTEGER) & STATUS (CHAR STRING)
printf("STATUS : %s\n",stat);
}

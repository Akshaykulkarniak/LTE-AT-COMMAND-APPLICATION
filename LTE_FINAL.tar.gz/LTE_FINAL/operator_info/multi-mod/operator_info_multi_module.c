/* Lte: Get the mobile operator name using AT cmds. 
*
* AUTHOR : AKSHAY KULKARNI
*/

#include <stdio.h>   
#include <string.h>  
#include <unistd.h>  
#include <fcntl.h>   
#include <errno.h>   
#include <termios.h> /* POSIX terminal control definitions */

/*FUNCTION PROTO-TYPES*/
int open_port_1(void);
int open_port_2(void);
int open_port_3(void);
int open_port_4(void);




void get_operator_name(char *operator, int mod) 
{
	int fd;  
	int n,i;
	char buf[100]={"\0"}; 
	char com[20]={"AT+COPS?\r"}; 
	struct termios options;
 
switch (mod)
{
case 1:
	fd = open_port_1();
	break;
case 2:
	fd = open_port_2();
	break;
case 3:
	fd = open_port_3();
	break;
case 4:
	fd = open_port_4();
	break;
default :
	printf("WRONG MODULE\n");
	break;
}	

	// Read the configuration of the port

	tcgetattr( fd, &options );

	/* SEt Baud Rate */

	cfsetispeed( &options, B115200 );
	cfsetospeed( &options, B115200 );

	//I don't know what this is exactly

	options.c_cflag |= ( CLOCAL | CREAD );

	// Set the Charactor size

	options.c_cflag &= ~CSIZE; /* Mask the character size bits */
	options.c_cflag |= CS8;    /* Select 8 data bits */

	// Set parity - No Parity (8N1)

	options.c_cflag &= ~PARENB;
	options.c_cflag &= ~CSTOPB;
	options.c_cflag &= ~CSIZE;
	options.c_cflag |= CS8;

	options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);

	// Disable Software Flow control

	options.c_iflag &= ~(IXON | IXOFF | IXANY);

	// Chose raw (not processed) output

	options.c_oflag &= ~OPOST;

	if ( tcsetattr( fd, TCSANOW, &options ) == -1 )
		printf ("1Error with tcsetattr = %s\n", strerror ( errno ) );
	else
		//printf ( "%s\n", "tcsetattr succeed" );

	fcntl(fd, F_SETFL, FNDELAY);


	// Write AT Commands to the serial port !!!

	{
		n = write(fd, com, strlen(com));
		if (n < 0)
			fputs("write() of 4 bytes failed!\n", stderr);
		else
		//printf ("Write succeed n  = %i\n", n );
			
		n=0;
		i=0;

		n = read( fd, buf, sizeof(buf) );

		//printf("buf: %s \n", buf ); 

		if(n>0)
		{
			char *token = strtok(buf, "\""); 
			
			//printf("buf: %s \n", buf ); 
		 	//printf("token: %s \n", token); 

			while (token != NULL)
			{
				token = strtok(NULL, "\"");
				//printf("token2: %s\n\n", token);
					
				strcpy(operator, token); 
				
				break;   
			}
		}
	
		if( strcmp(operator, "Limited Service") == 0)
			printf("Reply: Limited Service\n"); 
	}
	
	close(fd);

}           

int open_port_1(void)
{
	int fd;
 	fd = open("/dev/ttyUSB2", O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		perror("open_port: Unable to open /dev/ttyUSB2 - ");
	}
	else
		fcntl(fd, F_SETFL, FNDELAY);
	return (fd);
}


int open_port_2(void)
{
	int fd;
 	fd = open("/dev/ttyUSB6", O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		perror("open_port: Unable to open /dev/ttyUSB6 - ");
	}
	else
		fcntl(fd, F_SETFL, FNDELAY);
	return (fd);
}

int open_port_3(void)
{
	int fd;
 	fd = open("/dev/ttyUSB10", O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		perror("open_port: Unable to open /dev/ttyUSB10 - ");
	}
	else
		fcntl(fd, F_SETFL, FNDELAY);
	return (fd);
}

int open_port_4(void)
{
	int fd;
 	fd = open("/dev/ttyUSB14", O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		perror("open_port: Unable to open /dev/ttyUSB14 - ");
	}
	else
		fcntl(fd, F_SETFL, FNDELAY);
	return (fd);
}


/*
FUNCTION NAME : get_operator 
APPLICATION : TO GET THE OPERATOR NAME FROM DESIRED MODULE
INPUT : INTEGER (MODULE NUMBER)
OUTPUT : CHAR STRING (OPERATOR NAME)

*/






void get_operator(char *oper_name, int mod )
{
	int loop=0;
	char oper[30];
	char *operator;
	operator = oper;

	for( loop =0; loop < 3; loop++)
	{
		get_operator_name(oper,mod);
	
		if( strcmp(operator, "Limited Service") == 0)
		{	
			sleep(4);
			continue;
		}
		else
			break;
	}

	strcpy(oper_name, operator); 
}



 
int main()
{
	char oper[30];
	int module_number;
	printf("Enter module Number \n");
	scanf("%d",&module_number);
	get_operator(oper,module_number); // parameters passed : char string to store data , integer to send the module number
  	
	printf(" Mobile Operator: %s \n", oper );

	return 0; 
}








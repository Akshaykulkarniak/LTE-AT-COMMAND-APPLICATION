/* 
 *	
 *	APPLICATION : Get the mobile operator name & Type of connection using AT commands 
 *	DATE : 23/01/2018
 * 	AUTHOR : AKSHAY KULKARNI 
 */

#include <stdio.h>   
#include <string.h>  
#include <unistd.h>  
#include <fcntl.h>   
#include <errno.h>   
#include <termios.h> /* POSIX terminal control definitions */
#include<stdlib.h>
/*FUNCTION PROTO-TYPES*/
int open_port_1(void);
int open_port_2(void);
int open_port_3(void);
int open_port_4(void);




void get_operator_name(char *operator,char *gen, int mod) 
{
	int fd;  
	int n,i;
	char buf[100]={"\0"}; 
	char com[20]={"AT+COPS?\r"}; 
	struct termios options;
	char buffer[30]; 
	switch (mod)
	{
		case 1:
			fd = open_port_1();
			break;
		case 2:
			fd = open_port_2();
			break;
		case 3:
			fd = open_port_3();
			break;
		case 4:
			fd = open_port_4();
			break;
		default :
			printf("WRONG MODULE\n");
			break;
	}	

	// Read the configuration of the port

	tcgetattr( fd, &options );

	/* SEt Baud Rate */

	cfsetispeed( &options, B115200 );
	cfsetospeed( &options, B115200 );

	//I don't know what this is exactly

	options.c_cflag |= ( CLOCAL | CREAD );

	// Set the Charactor size

	options.c_cflag &= ~CSIZE; /* Mask the character size bits */
	options.c_cflag |= CS8;    /* Select 8 data bits */

	// Set parity - No Parity (8N1)

	options.c_cflag &= ~PARENB;
	options.c_cflag &= ~CSTOPB;
	options.c_cflag &= ~CSIZE;
	options.c_cflag |= CS8;

	options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);

	// Disable Software Flow control

	options.c_iflag &= ~(IXON | IXOFF | IXANY);

	// Chose raw (not processed) output

	options.c_oflag &= ~OPOST;

	if ( tcsetattr( fd, TCSANOW, &options ) == -1 )
		printf ("1Error with tcsetattr = %s\n", strerror ( errno ) );
	else
		//printf ( "%s\n", "tcsetattr succeed" );

		fcntl(fd, F_SETFL, FNDELAY);


	// Write AT Commands to the serial port !!!

	n = write(fd, com, strlen(com));
	if (n < 0)
		fputs("write() of 4 bytes failed!\n", stderr);
	else
		//printf ("Write succeed n  = %i\n", n );

		n=0;
	i=0;

	n = read( fd, buf, sizeof(buf) );

	//printf("buf: %s \n", buf ); 

	if(n>0)
	{
		char *token = strtok(buf, "\""); 


		token = strtok(NULL, "\"");

		strcpy(operator,token); 
		token = strtok(NULL, ",");
		strcpy(gen,token); 

	}

	close(fd);

}           

int open_port_1(void)
{
	int fd;
	fd = open("/dev/ttyUSB2", O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		perror("open_port: Unable to open /dev/ttyUSB2 - ");
	}
	else
		fcntl(fd, F_SETFL, FNDELAY);
	return (fd);
}


int open_port_2(void)
{
	int fd;
	fd = open("/dev/ttyUSB6", O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		perror("open_port: Unable to open /dev/ttyUSB6 - ");
	}
	else
		fcntl(fd, F_SETFL, FNDELAY);
	return (fd);
}

int open_port_3(void)
{
	int fd;
	fd = open("/dev/ttyUSB10", O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		perror("open_port: Unable to open /dev/ttyUSB10 - ");
	}
	else
		fcntl(fd, F_SETFL, FNDELAY);
	return (fd);
}

int open_port_4(void)
{
	int fd;
	fd = open("/dev/ttyUSB14", O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd == -1)
	{
		perror("open_port: Unable to open /dev/ttyUSB14 - ");
	}
	else
		fcntl(fd, F_SETFL, FNDELAY);
	return (fd);
}


/*
   FUNCTION NAME : get_operator 
APPLICATION : TO GET THE OPERATOR NAME FROM DESIRED MODULE
INPUT : INTEGER (MODULE NUMBER)
OUTPUT : CHAR STRING (OPERATOR NAME)

 */






void get_operator(char *oper_name,char *gen,int mod )
{
	char *gener;
	char pass[30];
	gener=pass;
	get_operator_name(oper_name,pass,mod);
	pass[1]=NULL;	
	if(*gener == '7')
	{
		strcpy(gen,"4G");
	}
	else if (*gener=='2')
	{
		strcpy(gen,"3G");
	}
	else if (*gener=='0')
	{
		strcpy(gen,"2G");
	}

}




int main()
{
	char oper[30];
	int module_number;
	char gen[30];
	printf("Enter module Number \n");
	scanf("%d",&module_number);
	get_operator(oper, gen, module_number); // parameters passed : char string to store operator name ,char string to store operator type  integer to send the module number

	printf("Mobile Operator: %s\n", oper );
	printf("Generation : %s\n",gen);
	return 0; 
}








/*
* APPLICATION : This program will return the number of LTE modules connected to the system 
* DATE : 7/1/2017
* Akshay Kulkarni, BANGALORE 
*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdlib.h>


/*NUMBER OF MODULES CONNECTED*/
int Number_of_modules_connected()  
{
	char command[50];
	strcpy(command,"ls /dev/qcqmi* | wc -w"); // checking number of modules connected 
	system(command);
}


int main()
{
	printf("Modules connected  : \n");
	Number_of_modules_connected(); 
	return 0;
}







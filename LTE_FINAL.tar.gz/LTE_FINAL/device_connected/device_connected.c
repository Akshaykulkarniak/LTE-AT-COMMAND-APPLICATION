/*
* APPLICATION : This program will return the number of LTE modules connected to the system 
* DATE : 7/1/2017
* Akshay Kulkarni, BANGALORE 
*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdlib.h>


/*NUMBER OF MODULES CONNECTED*/
int GetNumberOfLTEModules(char *num)  
{
	int val;
	FILE *f;
	char command[50];
	strcpy(command,"ls /dev/qcqmi* | wc -w"); // checking number of modules connected 
	system("ls /dev/qcqmi* | wc -w > num.txt"); // store the value in text file
	f=fopen("num.txt","r"); //open the text file
	if(f==NULL)
{
printf("failed\n");
}
else
{
while(!feof(f))
{
fgets(num,"%s",f); //copy the content till EOF
}
}
}


int main()
{
	char num[20];
	GetNumberOfLTEModules(num); 
	printf("Modules connected  :");
	printf( " %s \n",num);
	return 0;
}







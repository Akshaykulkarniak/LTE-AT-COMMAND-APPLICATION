/* FILE NAME : setgpsstate.c
* APPLICATION : ENABLING AND DISABLING GPS 
* DATE : 23/01/2018
*
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

void Set_GPS_State_On()
{
	FILE *ssh = popen("ssh root@192.168.2.2", "w");
	if(!ssh)
	{
		fprintf(stderr,"Could Not Open ssh session !!!!! \n ");
	}
	else
{	fputs("gnss start",ssh);
	fputs("\n",ssh);
		fprintf(stderr,"GPS STARTED !!!!! \n ");
	pclose(ssh);
	}
}


void Set_GPS_State_Off()
{
	FILE *ssh = popen("ssh root@192.168.2.2", "w");
	if(!ssh)
	{
		fprintf(stderr,"Could Not Open ssh session !!!!! \n ");
	}
else
{
	fputs("gnss stop",ssh);
	fputs("\n",ssh);
		fprintf(stderr,"GPS STOPPED !!!!! \n ");
	pclose(ssh);
	}
}

int SetGPSState(int status)
{

switch (status)
{
case 0:
	Set_GPS_State_Off();
	break;
case 1:
	Set_GPS_State_On();
	break;
default:
	printf("ERROR\n");
	break;

}


}



int main()
  {
int status;
printf("Enter your selection \n 1.Enable GPS\t 0. Disable GPS\t :");
scanf("%d",&status);
SetGPSState(status);  
return 0;
  }

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void Set_GPS_State_On();
int main()
{
Set_GPS_State_On();
return 0;
}

void Set_GPS_State_On()
{
FILE *ssh = popen("ssh root@192.168.2.2", "w");
//pid_t pid;
//pid = fork();
if(!ssh)
{
fprintf(stderr,"Could Not Open ssh session !!!!! \n ");
}
//if (!pid)
//{
fputs("gnss stop",ssh);
fputs("\n",ssh);
pclose(ssh);
//}
}


/* FILE NAME : setgpsstate.c
* APPLICATION : ENABLING AND DISABLING GPS 
* DATE : 23/01/2018
* AUTHOR : AKSHAY KULKARNI
*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<fcntl.h>

int Set_GPS_State_On(char *str)
{
int fd;
  fd = open("/dev/ttyUSB2", O_RDWR | O_NOCTTY | O_NDELAY);
  if (fd == -1)
  {
		fprintf(stderr,"Could Not Open ssh session !!!!! \n ");
	strcpy(str,"Device inactive : GPS session failed");
  }
else
{
	FILE *ssh = popen("ssh root@192.168.2.2", "w");
	if(!ssh)
	{
	fclose(ssh);
	}
else if(ssh)
{
	printf("YES\n");
	fputs("gnss start",ssh);
	fputs("\n",ssh);
	strcpy(str,"GPS session started");
	fclose(ssh);
}
}
}
int Set_GPS_State_Off(char *str)
{
int fd;
  fd = open("/dev/ttyUSB2", O_RDWR | O_NOCTTY | O_NDELAY);
  if (fd == -1)
  {
		fprintf(stderr,"Could Not Open ssh session !!!!! \n ");
	strcpy(str,"Device inactive : GPS session failed");
  }
else
{
	FILE *ssh = popen("ssh root@192.168.2.2", "w");
	if(!ssh)
	{
	pclose(ssh);
	}
else if(ssh)
	fputs("gnss stop",ssh);
	fputs("\n",ssh);
	strcpy(str,"GPS session stopped");
	fclose(ssh);
}
}
int SetGPSState(int status, char *str)
{

switch (status)
{
case 0:
	Set_GPS_State_Off(str);
	break;
case 1:
	Set_GPS_State_On(str);
	break;
default:
	printf("ERROR\n");
	strcpy(str,"ERROR");
	break;

}


}



int main()
  {
char str[30];
int status;
printf("Enter your selection \n 1.Enable GPS\t 0. Disable GPS\t :");
scanf("%d",&status);
SetGPSState(status,str);  
printf("RETURN : %s\n",str);
return 0;
  }
